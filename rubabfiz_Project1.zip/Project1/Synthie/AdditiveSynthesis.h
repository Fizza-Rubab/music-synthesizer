#pragma once
#include "Instrument.h"
#include "AdditiveSineWave.h"
#include <vector>
class CAdditiveSynthesis :
	public CInstrument
{
public:
	CAdditiveSynthesis(void);
	virtual ~CAdditiveSynthesis(void);
public:
	virtual void Start() override;
	virtual bool Generate() override;

	void SetFreq(double f) { m_sinewave.SetFreq(f); }
	void SetAmplitude(const std::vector<double>& a) { m_sinewave.SetAmplitude(a); }
	void SetDuration(double d) { m_duration = d * GetSecondsPerBeat(); }
	virtual void SetNote(CNote* note);

private:
	CAdditiveSineWave   m_sinewave;
	double m_duration;
	double m_time;
	double m_release;
	double m_attack;
	double m_sustain;
	double m_decay;
};
