#include "stdafx.h"
#include "Effects.h"
#include <string>

void Effects::FromXML(IXMLDOMNode* xml)
{
    // Get a list of all attribute nodes and the
// length of that list
    CComPtr<IXMLDOMNamedNodeMap> attributes;
    xml->get_attributes(&attributes);
    long len;
    attributes->get_length(&len);

    std::wstring name;

    // Loop over the list of attributes
    for (int i = 0; i < len; i++)
    {
        // Get attribute i
        CComPtr<IXMLDOMNode> attrib;
        attributes->get_item(i, &attrib);

        // Get the name of the attribute
        CComBSTR name;
        attrib->get_nodeName(&name);

        // Get the value of the attribute.  A CComVariant is a variable
        // that can have any type. It loads the attribute value as a
        // string (UNICODE), but we can then change it to an integer 
        // (VT_I4) or double (VT_R8) using the ChangeType function 
        // and then read its integer or double value from a member variable.

        CComVariant value;
        attrib->get_nodeValue(&value);

        if (name == L"name")
        {
            name = value.bstrVal;

            // Determine which effect to load:
            if (name == L"noisegate") {
                noisegate.FromXML(xml);
            }
            else if (name == L"chorus") {
                chorus.FromXML(xml);
            }
            else if (name == L"compression") {
                compression.FromXML(xml);
            }
            
        }
    }
}

double Effects::Process(double frame, std::vector<EffectSelector>* selection)
{
    double output = 0.0;
    for (int i = 0; i < selection->size(); ++i) {
        const EffectSelector& effect = selection->at(i);
        double drySignal = effect.dry * frame;
        double wetMix = effect.wet;
        int effectType = effect.index;
        switch (effectType) {
        case 0:
            output += wetMix * noisegate.Process(drySignal);
            break;
        case 1:
            output += wetMix * compression.Process(drySignal);
            break;
        case 2:
            output += wetMix * chorus.Process(drySignal);
            break;
        case -1:
            output += wetMix * drySignal;
            break;
        default:
            break;
        }
    }
    return output;
}
