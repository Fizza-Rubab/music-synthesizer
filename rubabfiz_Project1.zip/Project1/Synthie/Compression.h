#pragma once
class CCompression
{
public:
	CCompression(void);
	~CCompression(void);
    double Process(double frameValue);
    void FromXML(IXMLDOMNode* xml);

private:

    double m_threshold;
    double m_ratio;
    double m_attack;
    double m_release;
    double m_compressAmount;
    double m_envelope;
};
