#include "StdAfx.h"
#include "Compression.h"
#include <stdlib.h>
#include <cmath>

CCompression::CCompression() {
    m_threshold = -20.0;
    m_ratio = 4.0;
    m_attack = 0.001;
    m_release = 0.05;
    m_compressAmount = 0.0;
    m_envelope = 0.0;
}

CCompression::~CCompression() {}

void CCompression::FromXML(IXMLDOMNode* xml) {
    CComPtr<IXMLDOMNamedNodeMap> attributes;
    xml->get_attributes(&attributes);
    long len;
    attributes->get_length(&len);

    for (int i = 0; i < len; i++) {
        CComPtr<IXMLDOMNode> attrib;
        attributes->get_item(i, &attrib);

        CComBSTR name;
        attrib->get_nodeName(&name);
        CComVariant value;
        attrib->get_nodeValue(&value);

        if (name == "threshold") {
            value.ChangeType(VT_R8);
            m_threshold = value.dblVal;
        }
        else if (name == "ratio") {
            value.ChangeType(VT_R8);
            m_ratio = value.dblVal;
        }
        else if (name == "attack") {
            value.ChangeType(VT_R8);
            m_attack = value.dblVal;
        }
        else if (name == "release") {
            value.ChangeType(VT_R8);
            m_release = value.dblVal;
        }
    }
}

double CCompression::Process(double frameValue) {
    double inputLevel = 20.0 * log10(abs(frameValue) + 0.00001);
    if ((inputLevel - m_threshold) > 0) {
        m_compressAmount = (inputLevel - m_threshold) / m_ratio;
    }
    else {
        m_compressAmount = 0.0;
    }
    double gain = inputLevel - m_compressAmount;
    double change = gain - m_envelope;
    if (change > 0.0) {
        m_envelope += change * m_attack;
    }
    else {
        m_envelope += change * m_release;
    }
    return frameValue * pow(10.0, (m_envelope - inputLevel) / 20.0);
}
