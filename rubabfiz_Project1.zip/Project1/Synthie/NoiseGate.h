#pragma once

class CNoiseGate {
public:
    ~CNoiseGate();
    double Process(double frameIn);
    void FromXML(IXMLDOMNode* xml);
private:
    double m_threshold = 0.0;
    double m_gate = 1.0;
};