#pragma once
#include "Chorus.h"
#include "NoiseGate.h"
#include "Compression.h"

#include <vector>
#include <string>

struct EffectSelector {
	int index;
	double dry;
	double wet;
};

class Effects
{
public:

	Effects() = default;
	void FromXML(IXMLDOMNode* xml);
	double Process(double frame, std::vector<EffectSelector>* selector);
	static int NameToIndex(std::wstring name){
		if (name == L"noisegate") {
			return 0;
		}
		else if (name == L"compression") {
			return 1;
		}
		else if (name == L"chorus") {
			return 2;
		}
		else if (name == L"none") {
			return -1;
		}
	}

private:

	CChorus chorus;
	CNoiseGate noisegate;
	CCompression compression;
};
