#pragma once
#include <vector>

class CChorus
{
public:
    CChorus();
    ~CChorus();
    double Process(double frameIn);
    void FromXML(IXMLDOMNode* xml);

private:
    std::vector<double> m_delayBuffer;
    int m_bufferSize;
    int m_writeIndex;
    double m_rate;
    double m_range;
    double m_delay;
    int m_sampleRate;
};