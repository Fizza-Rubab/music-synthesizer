#include "stdafx.h"
#include "AdditiveSynthesis.h"
#include "Notes.h"
#include <string>
#include <sstream>
#include <vector>

CAdditiveSynthesis::CAdditiveSynthesis(void)
{
    m_attack = 0;
    m_release = 0;
    m_decay = 0;
    m_sustain = 1.0;
}


CAdditiveSynthesis::~CAdditiveSynthesis()
{
}


void CAdditiveSynthesis::Start()
{
    m_time = 0;
    m_sinewave.SetSampleRate(GetSampleRate());
    m_sinewave.SetDuration(m_duration);
    m_sinewave.Start();
}

bool CAdditiveSynthesis::Generate()
{
    m_sinewave.Generate();
    m_frame[0] = m_sinewave.Frame(0);
    m_frame[1] = m_sinewave.Frame(1);

    double factor = 1.0;
    if (m_time < m_attack) {
        factor = m_time / m_attack;
    }
    else if (m_time < (m_attack + m_decay)) {
        double decay_time = m_time - m_attack;
        factor = 1.0 + (m_sustain - 1.0) * (decay_time / m_decay);
    }
    else if (m_time > (m_duration - m_release) && m_release > 0) {
        double release_time = m_time - (m_duration - m_release);
        factor = m_sustain * (1.0 - release_time / m_release);
    }
    else {
        factor = m_sustain;
    }
    m_frame[0] *= factor;
    m_frame[1] *= factor;

    m_time += GetSamplePeriod();
    return m_time < m_duration;
}


void CAdditiveSynthesis::SetNote(CNote* note)
{
    // Get a list of all attribute nodes and the
    // length of that list
    CInstrument::LoadEffects(note->PNode());
    CComPtr<IXMLDOMNamedNodeMap> attributes;
    note->Node()->get_attributes(&attributes);
    long len;
    attributes->get_length(&len);

    // Loop over the list of attributes
    for (int i = 0; i < len; i++)
    {
        // Get attribute i
        CComPtr<IXMLDOMNode> attrib;
        attributes->get_item(i, &attrib);

        // Get the name of the attribute
        CComBSTR name;
        attrib->get_nodeName(&name);

        // Get the value of the attribute.  A CComVariant is a variable
        // that can have any type. It loads the attribute value as a
        // string (UNICODE), but we can then change it to an integer 
        // (VT_I4) or double (VT_R8) using the ChangeType function 
        // and then read its integer or double value from a member variable.
        CComVariant value;
        attrib->get_nodeValue(&value);

        if (name == "duration")
        {
            value.ChangeType(VT_R8);
            SetDuration(value.dblVal);
        }
        else if (name == "note")
        {
            SetFreq(NoteToFrequency(value.bstrVal));
        }
        else if (name == "amplitudes")
        {
            std::wstring wide(value.bstrVal);
            std::string str(wide.begin(), wide.end());
            std::stringstream ss(str);
            std::string item;
            std::vector<double> harmonics;

            while (std::getline(ss, item, ' ')) {
                harmonics.push_back(std::stod(item));
            }

            SetAmplitude(harmonics);
        }
        else if (name == "ADSR") {
            std::wstring wide(value.bstrVal);
            std::string str(wide.begin(), wide.end());

            std::stringstream ss(str);
            std::string item;

            std::getline(ss, item, char(32));
            m_attack = atof(item.c_str()) * m_duration;

            std::getline(ss, item, char(32));
            m_decay = m_attack + atof(item.c_str()) * m_duration;

            std::getline(ss, item, char(32));
            m_sustain = atof(item.c_str());

            std::getline(ss, item, char(32));
            m_release = atof(item.c_str()) * m_duration;
        }
        else if (name == "vibrato") {
            std::wstring wide(value.bstrVal);
            std::string str(wide.begin(), wide.end());

            std::stringstream ss(str);
            std::string item;

            std::getline(ss, item, char(32));
            m_sinewave.SetVibratoRate(atof(item.c_str()));

            std::getline(ss, item, char(32));
            m_sinewave.SetVibratoFreq(atof(item.c_str()));
        }

    }

}