#pragma once
#include "AudioNode.h"
#include <vector>
#include <cmath>

class CAdditiveSineWave : public CAudioNode
{
public:
    CAdditiveSineWave();
    virtual ~CAdditiveSineWave();
    virtual void Start() override;
    virtual bool Generate() override;
    void SetFreq(double f) { m_freq = f; }
    void SetAmplitude(const std::vector<double>& a) { m_amplitudes = a; }
    void SetDuration(double d) { m_duration = d; }
    void SetVibratoRate(double d) { m_vibratoRate = d; }
    void SetVibratoFreq(double d) { m_vibratoFreq = d; }

private:
    double m_duration;
    double m_freq;
    std::vector<double> m_amplitudes;
    double m_amplitude;
    int m_index;
    double m_vibratoRate;
    double m_vibratoFreq;
    double m_phase1 = 0.0;
    double m_phase2 = 0.0;
};
