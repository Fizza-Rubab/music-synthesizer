#include "stdafx.h"
#include "AdditiveSineWave.h"
#include <iostream>
#include <cmath>
#include <algorithm>

CAdditiveSineWave::CAdditiveSineWave(void)
{
	m_vibratoFreq = 0.0;
	m_vibratoRate = 0.0;
	m_amplitude = 1.0;
	m_amplitudes.resize(8, 0.0);
	m_amplitudes[0] = 1.0;
	m_freq = 440.0;
}

CAdditiveSineWave::~CAdditiveSineWave(void)
{
}

void CAdditiveSineWave::Start()
{
	m_index = 0;
	m_phase1 = 0.0;
	m_phase2 = 0.0;
}

bool CAdditiveSineWave::Generate()
{
	if (m_index >= int(m_duration * GetSampleRate())) {
		m_index = 0;
		return false;
	}
	double sample = 0;
	m_amplitudes[0] = 1.0;
	for (size_t harmonic = 1; harmonic * m_freq <= 22050 && harmonic <= m_amplitudes.size(); harmonic++) {
		//TRACE("The value of x is %f\n", m_amplitudes[harmonic - 1]);
		sample += (m_amplitude * m_amplitudes[harmonic - 1] * sin(harmonic * m_phase1));
	}

	m_phase2 += (2 * PI * m_vibratoRate) / GetSampleRate();
	m_phase1 += (2 * PI * (m_freq + m_vibratoFreq * sin(m_phase2))) / GetSampleRate();
	short outputSample = (sample < -32768) ? -32768 : (sample > 32767) ? 32767 : short(sample);
	m_frame[1] = m_frame[0] = outputSample;
	m_index++;

	return true;
}
