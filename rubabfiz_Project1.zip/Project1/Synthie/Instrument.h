#pragma once
#include <vector>            // Required for std::vector
#include "AudioNode.h"
#include "Note.h"
#include "Synthesizer.h"
#include "Effects.h"

class CInstrument :
    public CAudioNode
{
public:
    CInstrument();
    CInstrument(double);
    virtual ~CInstrument();

    CSynthesizer* GetSynth() const { return this->synth; }
    void SetSynth(CSynthesizer* syn) { this->synth = syn; }
    virtual void SetNote(CNote* note) = 0;
    void LoadEffects(IXMLDOMNode* xml);
    void LoadEffect(IXMLDOMNode* xml);
    std::vector<EffectSelector>* GetSelectedEffects() { return &this->effects; }

private: // It's a good practice to keep members private
    double m_time = 0;
    CSynthesizer* synth;
    std::vector<EffectSelector> effects;
};
