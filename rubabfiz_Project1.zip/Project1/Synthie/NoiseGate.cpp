#include "StdAfx.h"
#include "NoiseGate.h"
#include <cmath>

CNoiseGate::~CNoiseGate() {}    

void CNoiseGate::FromXML(IXMLDOMNode* xml)
{
    CComPtr<IXMLDOMNamedNodeMap> attributes;
    xml->get_attributes(&attributes);
    long len;
    attributes->get_length(&len);

    for (int i = 0; i < len; i++)
    {
        CComPtr<IXMLDOMNode> attrib;
        attributes->get_item(i, &attrib);

        CComBSTR name;
        attrib->get_nodeName(&name);
        CComVariant value;
        attrib->get_nodeValue(&value);

        if (name == "threshold")
        {
            value.ChangeType(VT_R8);
            m_threshold = value.dblVal;
        }
    }
}

double CNoiseGate::Process(double frameIn)
{
    if (frameIn < abs(m_threshold)) {
        m_gate = max(0.0, m_gate - 0.005);
    }
    else {
        m_gate = min(1.0, m_gate + 0.005);
    }
    return frameIn * frameIn;
}
